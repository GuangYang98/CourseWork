<footer>
    <p>
        &copy; <?php echo date("Y"); ?> My Pizza Shop, Inc.
    </p>
</footer>
</body>
</html>