-- show db contents
-- with doubled-up tablenames
select 'menu_toppings';
select * from menu_toppings;
select 'menu_sizes';
select * from menu_sizes;
select 'shop_users';
select * from shop_users;
select 'pizza_orders';
select * from pizza_orders;
select 'order_topping';
select * from order_topping;
select 'status_values';
select * from status_values;
select 'pizza_sys_tab';
select * from pizza_sys_tab;